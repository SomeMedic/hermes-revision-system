"""
Hermes Revision System Command Line Interface
"""

from .hrs_cli import cli

__all__ = ['cli'] 